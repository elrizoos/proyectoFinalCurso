<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Gestor de Alumnos - Chus-Álvarez-Pilates</title>
</head>

<body>
    

    <?php $__env->startSection('content'); ?>
        <div class="container">
            <form class="row" action="<?php echo e(url('/alumnos')); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>

                <?php echo $__env->make('alumnos.form', ['modo' => 'Crear'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </form>
        </div>
    <?php $__env->stopSection(); ?>
</body>

</html>

<?php echo $__env->make('layouts.app', ['modo' => 'Crear'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\proyectoFinal\resources\views/alumnos/create.blade.php ENDPATH**/ ?>