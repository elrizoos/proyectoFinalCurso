<?php $__env->startSection('content'); ?>
<div class="container">
    
    <form class="row" action="<?php echo e(url('/empleados/'.$empleado->id)); ?>" method="POST" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <?php echo e(method_field('PATCH')); ?>

    <?php echo $__env->make('empleados.form', ['modo'=>'Editar'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', ['modo'=>'Editando empleado'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\proyectoFinal\resources\views/empleados/edit.blade.php ENDPATH**/ ?>