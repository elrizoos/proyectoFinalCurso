<?php $__env->startSection('content'); ?>
<div class="container">
    
    <form class="row" action="<?php echo e(url('/grupos-clases/clases/'.$clase->id)); ?>" method="POST" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <?php echo e(method_field('PATCH')); ?>

    <?php echo $__env->make('grupos-clases.clases.form', ['modo'=>'Editar'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', ['modo'=>'Editando grupo'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\proyectoFinal\resources\views/grupos-clases/clases/edit.blade.php ENDPATH**/ ?>