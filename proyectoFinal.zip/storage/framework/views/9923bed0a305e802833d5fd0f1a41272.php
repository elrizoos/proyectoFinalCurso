<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>

<body>
    
    <?php $__env->startSection('content'); ?>
        <div class="container">

            <?php if(Session::has('mensaje')): ?>
                <?php echo e(Session::get('mensaje')); ?>

            <?php endif; ?>


            <div class="row">
                <div class="col col-4">
                    <div class="contenedorTarjeta">
                        <h3>Control Alumnos</h3>
                        <ul>
                            <li>
                                <a href="<?php echo e(url('/alumnos/create')); ?>">Crear nuevo alumno</a>
                            </li>
                            <li>
                                <a href="#" onclick="buscar()">Gestionar Alumno</a>
                                <script>
                                    function buscar(){
                                        //Url donde se encuentra el contenido que voy a mostrar en la ventana emergente
                                        var url = "<?php echo e(route('alumnos.search')); ?>";
                                        
                                        //Ancho y Alto de la ventana emergente
                                        var width = 600;
                                        var height = 400;

                                        //Opciones adicionales de la ventana emergente
                                        var opciones = 'toolbar=no, location=no, directories=no, status=no';

                                        //Abrir la ventana emergente
                                        window.open(url, 'PopupWindow', opciones);
                                    }
                                </script>
                            </li>
                            
                        </ul>
                        <a href="<?php echo e(url('alumnos/')); ?>"><input type="button" value="Ir a la configuración general"></a>
                    </div>
                </div>
                <div class="col col-4">
                    <div class="contenedorTarjeta">
                        <h3>Control Empleados</h3>
                        <ul>
                            <li><a href="<?php echo e(route('empleados.create')); ?>">Crear nuevo empleado</a></li>
                            <li>Editar alumno</li>
                            <li>Borrar alumno</li>
                        </ul>
                        <input type="button" value="Ir a la configuración general">
                    </div>
                </div>
                <div class="col col-4">
                    <div class="contenedorTarjeta">
                        <h3>Control Grupos</h3>
                        <ul>
                            <li>Crear nuevo alumno</li>
                            <li>Editar alumno</li>
                            <li>Borrar alumno</li>
                        </ul>
                        <input type="button" value="Ir a la configuración general">
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col col-4">
                    <div class="contenedorTarjeta">
                        <h3>Control Clases</h3>
                        <ul>
                            <li>Crear nuevo alumno</li>
                            <li>Editar alumno</li>
                            <li>Borrar alumno</li>
                        </ul>
                        <input type="button" value="Ir a la configuración general">
                    </div>
                </div>
                <div class="col col-4">
                    <div class="contenedorTarjeta">
                        <h3>Control Horarios</h3>
                        <ul>
                            <li>Crear nuevo alumno</li>
                            <li>Editar alumno</li>
                            <li>Borrar alumno</li>
                        </ul>
                        <input type="button" value="Ir a la configuración general">
                    </div>
                </div>
                <div class="col col-4">
                    <div class="contenedorTarjeta">
                        <h3>Control Altas</h3>
                        <ul>
                            <li>Crear nuevo alumno</li>
                            <li>Editar alumno</li>
                            <li>Borrar alumno</li>
                        </ul>
                        <input type="button" value="Ir a la configuración general">
                    </div>
                </div>
            </div>
        </div>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', ['modo' => 'Centro de Control'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\proyectoFinal\resources\views/index.blade.php ENDPATH**/ ?>