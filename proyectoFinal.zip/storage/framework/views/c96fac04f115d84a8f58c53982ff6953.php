<!DOCTYPE html>
<html lang="en">
<?php
use Carbon\Carbon;

?>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>

<body>
    
    
    <?php $__env->startSection('content'); ?>
        <div class="container">
            <a href="<?php echo e(url('horarios/create')); ?>">Crear nuevo registro</a>
            <form action="<?php echo e(url('/horarios/')); ?>" method="GET">
                <label for="semana">Selecciona la semana:</label>
                <input type="week" name="semana">
                <button type="submit">Mostrar</button>
            </form>
            <?php if(isset($currentDate)): ?>
                <div class="navigation-buttons">
                    <a href="<?php echo e(url('/horarios?date=' .$currentDate->copy()->subWeek()->toDateString())); ?>">Semana
                        Anterior</a>
                    <span>Semana del <?php echo e($currentDate->startOfWeek()->toFormattedDateString()); ?> al
                        <?php echo e($currentDate->endOfWeek()->toFormattedDateString()); ?></span>
                    <a href="<?php echo e(url('/horarios?date=' .$currentDate->copy()->addWeek()->toDateString())); ?>">Semana
                        Posterior</a>
                </div>
            <?php endif; ?>
            <h3>Semana seleccionada</h3>
            <table class="table text-center align-middle table-striped-columns table-responsive fs-6"
                style="left:5%; width:100%">
                <thead>
                    <tr>
                        <th>Tramos Horarios</th>
                        <?php $__currentLoopData = ['Lunes', 'Martes', 'Miércoles', 'Jueves', 'Viernes']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $dia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <th>
                                <?php echo e($dia); ?><br>
                                <?php echo e($currentDate->startOfWeek()->addDays($index)->format('Y-m-d')); ?>

                            </th>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = ['10:00 --- 11:20', '11:30 --- 12:50', '13:00 --- 14:20', '15:00 --- 16:20', '16:30 --- 17:50', '18:00 --- 19:20', '19:30 --- 20:50']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tramo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($tramo); ?></td>
                            <?php $__currentLoopData = ['Lunes', 'Martes', 'Miércoles', 'Jueves', 'Viernes']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $indexDia => $dia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <td>
                                    <?php
                                        $fechaDia = $currentDate
                                            ->copy()
                                            ->startOfWeek()
                                            ->addDays($indexDia)
                                            ->format('Y-m-d');
                                        $matchedHorario = $horarios->first(function ($horario) use ($dia, $tramo) {
                                            return $horario->diaSemana == $dia && substr($horario->horaInicio, 0, 5) . ' --- ' . substr($horario->horaFin, 0, 5) == $tramo;
                                        });
                                    ?>

                                    <?php if($matchedHorario): ?>
                                    <?php
                                        $idHorario = $matchedHorario->id
                                    ?>
                                        <a href="<?php echo e(url('horarios/edit', ['dia' => $dia,'tramo' => $tramo,'fecha' => $fechaDia, 'id' => $idHorario])); ?>">
                                        <?php echo e($matchedHorario->clase->nombre); ?>

                                        </a>
                                    <?php else: ?>
                                        <a href="<?php echo e(url('horarios/create', ['dia' => $dia,'tramo' => $tramo,'fecha' => $fechaDia])); ?>">Crear</a>
                                    <?php endif; ?>
                                </td>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </tbody>


            </table><?php echo e($horarios); ?>

        </div>
    <?php $__env->stopSection(); ?>
</body>





</html>

<?php echo $__env->make('layouts.app', ['modo' => 'Horarios'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\proyectoFinal\resources\views/horarios/index.blade.php ENDPATH**/ ?>