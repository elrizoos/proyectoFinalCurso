       <h1><?php echo e($modo); ?> clase</h1>

       

       <?php if(count($errors) > 0): ?>
           <div class="alert alert-danger" role="alert">
               <ul>
                   <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                       <li> <?php echo e($error); ?></li>
                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               </ul>
           </div>
       <?php endif; ?>


       <div class="form-group">
           <label for="nombre">Nombre: </label>
           <input class="form-control" type="text" name="nombre"
               id="nombre"value="<?php echo e(isset($clase->nombre) ? $clase->nombre : old('nombre')); ?>">
       </div>
       <div class="form-group">
           <label for="nivel">Nivel </label>
           <input class="form-control" type="text" name="nivel"
               id="nivel"value="<?php echo e(isset($clase->nivel) ? $clase->nivel : old('nivel')); ?>">
       </div>
      
       
       <div class="form-group">
           <input class="btn btn-success" type="submit" value="<?php echo e($modo); ?> datos clase">

           <a class="btn btn-primary" href="<?php echo e(url('grupos-clases/clases/')); ?>">Regresar</a>
       </div>
<?php /**PATH C:\xampp\htdocs\proyectoFinal\resources\views/grupos-clases/clases/form.blade.php ENDPATH**/ ?>